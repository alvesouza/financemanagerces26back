create function check_user_validation() returns trigger
    language plpgsql
as
$$
declare
    begin
        raise notice 'id = %', new.id_user;
        if new.account_type = 'S' then
            if new.password is null then
                raise exception 'when user doesnt use auth account it need a password';
                return null;
            end if;

        elsif not(new.account_type = 'F' OR new.account_type = 'G') then
                raise exception 'when user is not STANDARD it need to use google or facebook';
                return null;
        end if;
        if new.status is null then
            new.status := '0';
            new.id_comfirm_route := generate_string(10);
        end if;
      RETURN new;

    end;
$$;

alter function check_user_validation() owner to oujsfxlruvvmux;

