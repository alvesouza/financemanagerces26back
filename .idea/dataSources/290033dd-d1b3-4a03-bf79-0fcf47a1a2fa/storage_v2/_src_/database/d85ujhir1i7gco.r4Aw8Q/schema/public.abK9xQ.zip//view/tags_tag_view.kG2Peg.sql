create view tags_tag_view(id_tag, id_user, tag) as
SELECT tags.id_tag,
       tags.id_user,
       tags.tag
FROM tags
ORDER BY tags.tag, tags.id_user, tags.id_tag;

alter table tags_tag_view
    owner to oujsfxlruvvmux;

