create view expenses_tag_order_user_id
            (id_user, id_expense, tag, description, paid, value, date, remindercreated, paid_day) as
SELECT expenses.id_user,
       expenses.id_expense,
       tags.tag,
       expenses.description,
       expenses.paid,
       expenses.value,
       expenses.date,
       expenses.remindercreated,
       expenses.paid_day
FROM expenses
         LEFT JOIN tags ON tags.id_tag = expenses.id_tag
ORDER BY expenses.id_user, expenses.id_expense;

alter table expenses_tag_order_user_id
    owner to xzdyuyszpnfeob;

