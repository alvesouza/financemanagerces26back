create procedure blabla()
    language plpgsql
as
$$
declare
        id int;
        t text := '';
    begin
        select id_tag = id from tags where tag = 'Luz';
        t := 'id is ' || id;
        raise notice 'id is %', id;
    end;
$$;

alter procedure blabla() owner to xzdyuyszpnfeob;

