create function update_expenses_tag_order_user_id_function() returns trigger
    language plpgsql
as
$$
declare
            id_tag_var int;
        begin
            id_tag_var = (select tags_tag_view.id_tag from
                        tags_tag_view where tags_tag_view.tag = new.tag
                                and tags_tag_view.id_user = new.id_user fetch first 1 rows only);
            if (id_tag_var is null) then
                insert into tags_tag_view (id_tag,id_user, tag) values (default,new.id_user, new.tag)
                returning id_tag into id_tag_var;

--                 id_tag_var = (select tags_tag_view.id_tag from
--                         tags_tag_view where tags_tag_view.tag = new.tag
--                                 and tags_tag_view.id_user = new.id_user fetch first 1 rows only);
            end if;
            if(new.paid is null) then
                new.paid := false;
            end if;
            update expenses
                set id_user = new.id_user,
                    description = new.description,
                    value = new.value, paid = new.paid,
                    reminderCreated = new.reminderCreated,
                    paid_day = new.paid_day,
                    date = new.date,
                    id_tag = id_tag_var
                where id_user = new.id_user and id_expense = new.id_expense;

            return new;
        end;
$$;

alter function update_expenses_tag_order_user_id_function() owner to xzdyuyszpnfeob;

