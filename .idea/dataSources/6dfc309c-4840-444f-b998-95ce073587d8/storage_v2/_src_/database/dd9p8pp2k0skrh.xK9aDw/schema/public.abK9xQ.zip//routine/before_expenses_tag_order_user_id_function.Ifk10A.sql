create function before_expenses_tag_order_user_id_function() returns trigger
    language plpgsql
as
$$
begin
            if(new.paid is null) then
                new.paid := false;
            end if;
        end;
$$;

alter function before_expenses_tag_order_user_id_function() owner to xzdyuyszpnfeob;

